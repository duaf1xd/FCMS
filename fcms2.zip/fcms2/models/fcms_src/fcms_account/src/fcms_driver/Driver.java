package fcms_driver;


import java.util.Vector;

import fcms_course.Course;
import fcms_profile.*;

public class Driver {

	public static void main(String[] args) {
//		StudentProfile sp1= new StudentProfile("1701040191", "Nguyen Duy Thai Son", "02/12/1999", "Male"
//				,"duaf1xd@gmail.com", "EEEEEEEE MACAREMA", "3C-17");
//		ManagerProfile mp1= new ManagerProfile("1740191", "Nguyen Duy Thai Son", "02/12/1999", "Male"
//				,"duaf1xd@gmail.com", "EEEEEEEE MACAREMA", "3C-17");
//		TeacherProfile tp1= new TeacherProfile("GV10512135", null, "02/12/1999", "Male"
//				,"duaf1xd@gmail.com", "EEEEEEEE MACAREMA", "Artificial Intel");
//		System.out.println(sp1.repOK());
//		System.out.println(sp1.toString());
//		System.out.println(mp1.toString());
		
		Course c1= new Course("XPS", "Xpecial Project Query", null);
		Vector<Integer> res= c1.getExtractedWeights();
		for(int i=0; i<res.size(); ++i) {
			System.out.println(res.get(i));
		}
		System.out.println(c1.setGrades(5, "4/6/14/16/60"));
		res= c1.getExtractedWeights();
		for(int i=0; i<res.size(); ++i) {
			System.out.println(res.get(i));
		}
		int[] grades= {87, 43, 50, 13, 29};
		System.out.println(c1.calculateFinalGrade(grades));
		System.out.println(c1.repOK());
		System.out.println(c1.toString());
		
	}

}
