package fcms_announcement;

public class Announcement {
	private String title;
	private String content;
	private String date;
	
	public Announcement(String title, String content, String date) {
		
		if(validator(title, content)) {
			this.title = title;
			this.content = content;
			this.date = date;
		}
		else System.out.println("Title or content not capitalized properly");
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Announcement [title=" + title + ", content=" + content + ", date=" + date + "]";
	}
	
	public boolean repOK() {
		return validator(this.title, this.content);
	}

	private boolean validator(String title, String content) {
		return validateTitle(title) && validateContent(content);
	}
	
	protected boolean validateTitle(String title){
		if(!Character.isUpperCase(title.charAt(0))) return false;
		else return true;
	}
	
	protected boolean validateContent(String content){
		if(!Character.isUpperCase(content.charAt(0))) return false;
		else return true;
	}
	
	

	
}
