package fcms_account;

public class StudentAccount extends Account {
	
	
	public StudentAccount(String username, String password, String role){
		super(username, password, role);
		if(validateUsername(username)) {
			this.setFacultyId(Integer.parseInt(username));
		}
	}
	
	

	@Override
	public String toString() {
		return "StudentAccount [getFacultyId()=" + getFacultyId() + ", getUsername()=" + getUsername()
				+ ", getPassword()=" + getPassword() + ", getRole()=" + getRole()+ "]";
	}



	@Override
	protected boolean validateUsername(String username) {
		if(username==null || username.isEmpty()) return false;
		if(username.length()!=10) return false;
		for(int i=0; i<username.length(); ++i) {
			if(!Character.isDigit(username.charAt(i))) {
				return false;
			}
		}
		return true;
	}
	

	
	@Override
	protected boolean validateRole(String role) {
		if(role==null || role.isEmpty()) return false;
		if (!role.equals("student")) {
			return false;
		}
		else return true;
	}
}
