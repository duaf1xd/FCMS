package fcms_account;

public class Account {
	private int facultyId;
	private String username;
	private String password;
	private String role;
	
	public Account(String username, String password, String role) {
		if(validator(username, password, role)) {
			this.username= username;
			this.password= password;
			this.role= role;
		}
		else System.out.println("Account: Failed validation");
	}
	


	public int getFacultyId() {
		return facultyId;
	}



	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}



	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		if(validateUsername(username)) this.username = username;
		else System.out.println("setUsername failed validation");
		
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		if(validatePassword(password)) this.password = password;
		else System.out.println("setPassword failed validation");
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		if(validateRole(role)) this.role= role;
		else System.out.println("setRole failed validation");
	}


	@Override
	public String toString() {
		return "Account [username=" + username + ", password=" + password + ", role=" + role + "]";
	}
	
	public boolean repOK() {
		return validator(this.username, this.password, this.role);
	}

	private boolean validator(String username, String password, String role) {
		return validateUsername(username) && validatePassword(password) && validateRole(role);
	}
	
	protected boolean validateUsername(String username){
		if(username==null || username.isEmpty()) return false;
		if(username.length()< 6) return false;
		else return true;
	}
	
	protected boolean validatePassword(String password){
		if(password==null || password.isEmpty()) return false;
		if(password.length()< 6) return false;
		else return true;
	}
	
	protected boolean validateRole(String role) {
		if(role==null || role.isEmpty()) return false;
		if(role.equals("student") || role.equals("manager") || role.equals("teacher")) return true;
		else return false;
	}
	
}
