package fcms_profile;

public class TeacherProfile extends Profile{
private String specialization;
	
	public TeacherProfile(String facultyID, String fullName, String dob
			, String gender, String email, String description, String specialization) {
		
		
		super(facultyID, fullName, dob, gender, email, description);
		if(super.repOK()) {
			if(validateSpecialization(specialization)) {
				this.specialization= specialization;
			}
			else System.out.println("TeacherProfile: Specialization validate failed");
		}
		else System.out.println("TeacherProfile: super() failed");
	}


	public String getSpecialization() {
		return specialization;
	}



	public boolean setSpecialization(String specialization) {
		if (validateSpecialization(specialization)) {
			this.specialization= specialization;
			return true;
		}
		else return false;
	}

	@Override
	public String toString() {
		return "TeacherProfile ["+ super.toString()+ " specialization=" + specialization + "]";
	}



	@Override
	public boolean repOK() {
		return super.repOK() && validateSpecialization(specialization);
	}



	private boolean validateSpecialization(String specialization) {
		if(specialization==null || specialization.isEmpty()) return false;
		if(specialization.length()>50 || !Character.isUpperCase(specialization.charAt(0))) {
			return false;
		}
		else return true;
	}
}
