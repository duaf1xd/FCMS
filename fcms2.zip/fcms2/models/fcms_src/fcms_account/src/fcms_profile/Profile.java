package fcms_profile;

public class Profile {
	private String facultyID;
	private String fullName;
	private String dob;
	private String gender;
	private String email;
	private String description;

	

	public Profile(String facultyID, String fullName, String dob, String gender
			, String email, String description) {
		if(validator(facultyID, fullName, dob, gender, email)) {
			this.facultyID = facultyID;
			this.fullName = fullName;
			this.dob = dob;
			this.gender = gender;
			this.email = email;
			this.description = description;
		}
		else System.out.println("Profile validation failed");
	}

	
	
	public String getFacultyID() {
		return facultyID;
	}



	public boolean setFacultyID(String facultyID) {
		if (validateFacultyID(facultyID)) {
			this.facultyID= facultyID;
			return true;
		}
		else return false;
	}



	public String getFullName() {
		return fullName;
	}



	public boolean setFullName(String fullName) {
		if (validateFullName(fullName)) {
			this.fullName= fullName;
			return true;
		}
		else return false;
	}



	public String getDob() {
		return dob;
	}



	public boolean setDob(String dob) {
		this.dob = dob;
		return true;
	}



	public String getGender() {
		return gender;
	}



	public boolean setGender(String gender) {
		if (validateGender(gender)) {
			this.gender= gender;
			return true;
		}
		else return false;
	}



	public String getEmail() {
		return email;
	}



	public boolean setEmail(String email) {
		if (validateEmail(email)) {
			this.email= email;
			return true;
		}
		else return false;
	}



	public String getDescription() {
		return description;
	}



	public boolean setDescription(String description) {
		this.description = description;
		return true;
	}

	

	@Override
	public String toString() {
		return "Profile [facultyID=" + facultyID + ", fullName=" + fullName + ", dob=" + dob + ", gender=" + gender
				+ ", email=" + email + ", description=" + description + "]";
	}



	public boolean repOK() {
		return validator(this.facultyID, this.fullName, this.dob, this.gender, this.email);
	}

	protected boolean validator(String facultyID, String fullName, String dob, String gender, String email) {
		return validateFacultyID(facultyID) && validateFullName(fullName) 
				&& validateDob(dob) && validateGender(gender) && validateEmail(email);
	}
	
	protected boolean validateFacultyID(String facultyID) {
		if(facultyID==null || facultyID.isEmpty()) return false;
		if(facultyID.length()<10) return false;
		else return true;
	}
	
	private boolean validateFullName(String fullName) {
		if(fullName==null || fullName.isEmpty()) return false;
		for(int i=0; i<fullName.length(); ++i) {
			if(Character.isDigit(fullName.charAt(i))) return false;
			if(fullName.charAt(i)==' ') {
				if(i== fullName.length()-1) return false;
				if(!Character.isUpperCase(fullName.charAt(i+1))) return false;
			}
		}
		return true;
	}
	
	private boolean validateDob(String dob) {
		if(dob==null || dob.isEmpty()) return false;
		else return true;
	}
	
	private boolean validateGender(String gender) {
		if(gender==null || gender.isEmpty()) return false;
		if(gender.equals("Male") || gender.equals("Female") || gender.equals("Other")) return true;
		else return false;
	}
	
	private boolean validateEmail(String email) {
		if(email==null || email.isEmpty()) return false;
		for(int i=0; i<email.length(); ++i) {
			if(email.charAt(i)=='@') return true;
		}
		return false;
	}
}
