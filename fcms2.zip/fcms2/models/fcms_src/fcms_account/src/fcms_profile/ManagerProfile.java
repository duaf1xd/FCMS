package fcms_profile;

public class ManagerProfile extends Profile {
	private String position;
	
	public ManagerProfile(String facultyID, String fullName, String dob
			, String gender, String email, String description, String position) {
		
		
		super(facultyID, fullName, dob, gender, email, description);
		if(super.repOK()) {
			if(validatePosition(position)) {
				this.position= position;
			}
			else System.out.println("ManagerProfile: position validate failed");
		}
		else System.out.println("ManagerProfile: super() failed");
	}



	public String getPosition() {
		return position;
	}


	public boolean setPosition(String position) {
		if (validatePosition(position)) {
			this.position= position;
			return true;
		}
		else return false;
	}



	@Override
	public String toString() {
		return "ManagerProfile ["+ super.toString()+ " position=" + position + "]";
	}



	@Override
	public boolean repOK() {
		return super.repOK() && validatePosition(position);
	}



	private boolean validatePosition(String position) {
		if(position==null || position.isEmpty()) return false;
		if(position.length()>50 || !Character.isUpperCase(position.charAt(0))) {
			return false;
		}
		else return true;
	}
}
