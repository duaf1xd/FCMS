package fcms_profile;

public class StudentProfile extends Profile{

	private String className;
	
	public StudentProfile(String facultyID, String fullName, String dob
			, String gender, String email, String description, String className) {
		
		
		super(facultyID, fullName, dob, gender, email, description);
		if(super.repOK()) {
			if(validateClassName(className)) {
				this.className= className;
			}
			else System.out.println("StudentProfile: className validate failed");
		}
		else System.out.println("StudentProfile: super() failed");
	}
	
	
	
	public String getClassName() {
		return className;
	}


	
	
	
	@Override
	public String toString() {
		return "StudentProfile ["+ super.toString()+ " className=" + className + "]";
	}



	@Override
	public boolean repOK() {
		return super.repOK() && validateClassName(className);
	}



	public boolean setClassName(String className) {
		if (validateClassName(className)) {
			this.className= className;
			return true;
		}
		else return false;
	}



	private boolean validateClassName(String className) {
		if(className==null || className.isEmpty()) return false;
		if(className.length()>15) {
			return false;
		}
		else return true;
	}
}
