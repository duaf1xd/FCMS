package fcms_course;

import java.util.Vector;

public class Course {
	private String courseCode;
	private String courseName;
	private String courseDescription;
	private int gradesCount= 1;
	private String gradesFormula= "100";
	private Vector<Integer> extractedWeights= new Vector<Integer>();
	
	
	public Course(String courseCode, String courseName, String courseDescription) {
		extractedWeights.add(100);
		if(validator(courseCode, courseName)) {
			this.courseCode = courseCode;
			this.courseName = courseName;
			this.courseDescription = courseDescription;
		}
		else System.out.println("Course validation failed");
	}

	public String getCourseCode() {
		return courseCode;
	}

	public boolean setCourseCode(String courseCode) {
		if(validateCourseCode(courseCode)) {
			this.courseCode= courseCode;
			return true;
		}
		return false;
	}

	
	public Vector<Integer> getExtractedWeights() {
		return extractedWeights;
	}
	
	public double calculateFinalGrade(int[] grades) {
		if(grades.length!= extractedWeights.size()) return -1;
		else {
			double finalGrade=0;
			for(int i=0; i<grades.length; ++i) {
				finalGrade+= ((double)grades[i])/100*((double)extractedWeights.get(i));
			}
			return finalGrade;
		}
	}

	public String getCourseName() {
		return courseName;
	}

	public boolean setCourseName(String courseName) {
		if(validateCourseName(courseName)) {
			this.courseName= courseName;
			return true;
		}
		return false;
	}

	public String getCourseDescription() {
		return courseDescription;
	}

	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}

	public boolean setGrades(int gradesCount, String gradesFormula) {
		if(validateGrades(gradesCount, gradesFormula)) {
			this.gradesCount= gradesCount;
			this.gradesFormula= gradesFormula;
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return "Course [courseCode=" + courseCode + ", courseName=" + courseName + ", courseDescription="
				+ courseDescription + ", gradesCount=" + gradesCount + ", gradesFormula=" + gradesFormula + "]";
	}
	
	
	
	public boolean repOK() {
		return  validator(courseCode, courseName);
	}
	
	private boolean validator(String courseCode, String courseName) {
		return validateCourseCode(courseCode) && validateCourseName(courseName);
	}

	private boolean validateCourseCode(String courseCode) {
		if(courseCode==null || courseCode.isEmpty()) return false;
		if(courseCode.length()!=3) return false;
		for(int i=0; i<courseCode.length(); ++i) {
			if(!Character.isUpperCase(courseCode.charAt(i))) return false;
		}
		return true;
	}

	private boolean validateCourseName(String courseName) {
		if(courseName==null || courseName.isEmpty()) return false;
		if(courseName.length()>60 || !Character.isUpperCase(courseName.charAt(0))) {
			return false;
		}
		else return true;
	}
	
	// gradesCount 5, gradesFormula "4/6/14/16/60"
	private boolean validateGrades(int gradesCount, String gradesFormula) {
		if(gradesFormula==null || gradesFormula.isEmpty()) return false;
		if(gradesCount< 1 || gradesCount> 10) return false;
		if(gradesCount== 1) 
		{
			if(gradesFormula.equals("100")) return true;
			else return false;
		}
		else 
		{
			int slashCount=0;
			Vector<Integer> slashPositions= new Vector<Integer>();
			Vector<Integer> temp= new Vector<Integer>();
			slashPositions.add(0);
			int percentage=0;
			for(int i=0; i<gradesFormula.length(); ++i) {
				if(!Character.isDigit(gradesFormula.charAt(i)) && gradesFormula.charAt(i)!='/') return false;
				if(gradesFormula.charAt(i)=='/') {
					if(i== gradesFormula.length()-1 || i==0) return false;
					else {
						++slashCount;
						slashPositions.add(i);
					}
				}
			}
			slashPositions.add(gradesFormula.length());
			int weight=0;
			if(slashCount!= gradesCount-1) return false;
			for(int i=0; i<slashCount+1; ++i) {
				if(i==0) {
					weight= Integer.parseInt(gradesFormula.substring(slashPositions.get(i), slashPositions.get(i+1)));
					percentage+= weight;
					temp.add(weight);
				}
				else {
					weight= Integer.parseInt(gradesFormula.substring(slashPositions.get(i)+1, slashPositions.get(i+1)));
					percentage+= weight;
					temp.add(weight);
				}
			}
			System.out.println("Total percentage is "+ percentage);
			if(percentage!=100) return false;
			else {
				extractedWeights.removeAllElements();
				for(int i=0; i<temp.size(); ++i) {
					extractedWeights.add(temp.get(i));
				}
				return true;
			}
		}
	}
	
}
