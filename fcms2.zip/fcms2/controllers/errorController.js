const express = require('express');
let router = express.Router();

router.get('/',(req,res)=>{
    res.render('error/errorPage', {
            style: 'common.css',
            errorMessage: req.query.status
    });
})

module.exports = router;
