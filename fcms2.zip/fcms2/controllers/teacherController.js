const express = require('express');
let router = express.Router();

let db= require('../sql/db_connection.js');

let java= require('java');

router.get('/',(req,res)=>{
	if(!req.session.teacher){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
		db.query("SELECT * FROM TEACHERPROFILE WHERE Account_Binded= ?", [req.session.displayID], (err, results, fields) =>{
			    	if(err){
			    		return console.error(err.message);
			    		res.redirect('/error?status='+err.message);
			    	}
			    	else{
			    		req.session.profileID= results[0].Profile_ID;
			    		console.log(req.session.profileID)
			    		res.render('teacher/teacherHomepage', {
				            style: 'common.css',
				    	});
			    	}
	    })
	}
})

router.get('/viewAssignedCourses',(req,res)=>{
	if(!req.session.teacher){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
    	console.log(req.session.profileID)
    	db.query("SELECT * FROM TEACHINGSTAFF WHERE Teacher_ID= ?", [req.session.profileID], (err, results, fields) =>{
    				if(err){
			    		return console.error(err.message);
			    		res.redirect('/error?status='+err.message);
			    	}
			    	else{
			    		res.render('teacher/viewAssignedCourseList', {
				            style: 'common.css',
				            course: results
				    	});
			    	}
    	})
	}
})

module.exports = router;