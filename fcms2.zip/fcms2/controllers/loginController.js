const express = require('express');
let router = express.Router();

let db= require('../sql/db_connection.js');

router.get('/',(req,res)=>{
	if(req.session.logged_in){
		res.redirect('/error?status=You%20are%20already%20logged%20in,%20please%20click%20button%20below%20to%20go%20back%20to%20user%20homepage')
	}
	else{
	    res.render('login/loginPage', {
	            style: 'common.css',
	            errorMessage: req.query.status
	    });
	}
})

router.post('/',(req,res)=>{
    if(req.body.username.length<6 || req.body.password.length<6) {
    	res.redirect('/login?status=Username%20password%20too%20short');
    }
    else{
	    let sql= "SELECT * FROM accounts WHERE username = ? AND password = ?";
		let account= [req.body.username, req.body.password];
		db.query(sql, account, (err, results, fields) =>{
			console.log(results);
		    if(!results.length){
		    	res.redirect('/login?status=Invalid%20credentials');
		    }
		    else{
		    	//console.log('found match '+ results[0].Role);
		    	if(results[0].Role==='manager'){
		    		req.session.logged_in= true;
		    		req.session.manager= true;
		    		req.session.displayID= results[0].Numeric_ID;
		    		res.redirect('/manager');
		    	}
		    	else if(results[0].Role==='teacher'){
		    		req.session.logged_in= true;
		    		req.session.teacher= true;
		    		req.session.displayID= results[0].Numeric_ID;
		    		res.redirect('/teacher');
		    	}
		    	else if(results[0].Role==='student'){
		    		req.session.logged_in= true;
		    		req.session.student= true;
		    		req.session.displayID= results[0].Numeric_ID;
		    		res.redirect('/student');
		    	}		
		    	else res.redirect('//login?status=Account%20is%20corrupt');
		    }
		})
	}
})

module.exports = router;