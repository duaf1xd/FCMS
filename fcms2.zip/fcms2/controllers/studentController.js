const express = require('express');
let router = express.Router();

let db= require('../sql/db_connection.js');

let java= require('java');


router.get('/',(req,res)=>{
	if(!req.session.student){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
    	res.render('student/studentHomepage', {
            style: 'common.css',
    	});
	}
})

router.get('/viewAnnouncementList',(req,res)=>{
	if(!req.session.student){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
		db.query('SELECT * FROM ANNOUNCEMENTS ORDER BY Announcement_ID DESC', function(err, results, fields){
				console.log(results);
				res.render('student/viewAnnouncementList', {
			            style: 'common.css',
			            statusMessage: req.query.status,
			            announcement: results,
			    });
		});
	}
})

router.get('/viewAnnouncementDetails', (req,res)=>{
    console.log(req.query.id)
    if(!req.session.student){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
		db.query('SELECT * FROM ANNOUNCEMENTS WHERE Announcement_ID= ?', [req.query.id], function(err, results, fields){
				console.log(results);
				res.render('student/viewAnnouncementDetails', {
			            style: 'common.css',
			            statusMessage: req.query.status,
			            announcement: results,
			    });
		});
	}
})

router.get('/viewCourseList', (req,res)=>{
    if(!req.session.student){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
		db.query('SELECT * FROM COURSES', function(err, results, fields){
				res.render('student/viewCourseList', {
			            style: 'common.css',
			            statusMessage: req.query.status,
			            course: results,
			    });
		});
	}
})

module.exports = router;
