const express = require('express');
let router = express.Router();

let db= require('../sql/db_connection.js');

let java= require('java');

java.classpath.push('./models/fcms_account.jar'); // one dot for this, two dot for that...
java.classpath.push('./models/fcms_announcement.jar');
java.classpath.push('./models/fcms_profile.jar');
java.classpath.push('./models/fcms_course.jar')
let Account= java.import("fcms_account.Account");
let StudentAccount= java.import("fcms_account.StudentAccount");
let Announcement= java.import("fcms_announcement.Announcement");
let StudentProfile= java.import("fcms_profile.StudentProfile");
let TeacherProfile= java.import("fcms_profile.TeacherProfile");
let ManagerProfile= java.import("fcms_profile.ManagerProfile");
let Course= java.import("fcms_course.Course");

router.get('/',(req,res)=>{
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
    	res.render('manager/managerHomepage', {
            style: 'common.css',
    	});
	}
})

//User list

router.get('/showUserList',(req,res)=>{
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
		db.query('SELECT * FROM ACCOUNTS', function(err, results, fields){
				console.log(results);
				res.render('manager/showUserList', {
			            style: 'common.css',
			            statusMessage: req.query.status,
			            account: results,
			    });
		});
	}
})

//CREATE NEW ACCOUNT

router.get('/createNewAccount',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/createNewAccountHomepage', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

router.get('/createNewStudent',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/createNewStudent', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

function reformatDate(date){
    result= date.charAt(8)+ date.charAt(9)+ '/'+ date.charAt(5) 
        + date.charAt(6)+ '/'+ date.charAt(0)+ date.charAt(1)+ date.charAt(2)+ date.charAt(3);
    return result;
}

router.post('/createNewStudent', (req, res)=>{
	let accountObject;
	let profileObject;
	let insertId;
	console.log(req.body);

	accountObject= new StudentAccount(req.body.username, req.body.username, 'student');
	profileObject= new StudentProfile(req.body.username, req.body.full_name, reformatDate(req.body.dob)
		, req.body.gender, req.body.email, "No description yet", req.body.class_id);
	console.log(accountObject.toString());
	console.log(profileObject.toString());

	if(accountObject.repOK() && profileObject.repOK()){
		let sql= "INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (?, ?, ?, ?)";
		let account= [null, accountObject.getUsername(), accountObject.getPassword(), accountObject.getRole()];
	    db.query(sql, account, (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/manager/createNewStudent?status='+err.message);
	    	}
	    	else{
	    		console.log("ID inserted:" + results.insertId);
	    		insertId= results.insertId;
	    		let sql2= "INSERT INTO StudentProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Class_ID, Account_Binded)"
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
				let profile2= [null, profileObject.getFacultyID(), profileObject.getFullName()
				, profileObject.getDob(), profileObject.getGender(), profileObject.getEmail()
				, profileObject.getDescription(), profileObject.getClassName(), insertId];
				db.query(sql2, profile2, (err2, results2, fields2) =>{
			    	if(err2){
			    		return console.error(err2.message);
			    		res.redirect('/manager/createNewStudent?status='+err2.message);
			    	}
			    	else{
			    		console.log("ID inserted:" + results.insertId);
			    		res.redirect('/manager/createNewStudent?status=Created%20sucessfully');
			    	}
			    })	
	    	}
	    })
	}
	else res.redirect('/error?status=Account%20or%20profile%20validation%20failed');

	//console.log("This is session manager id: "+ req.session.displayID);

	// if(accountObject.repOK() && profileObject.repOK()){
	// 	let sql= "INSERT INTO StudentProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Class_ID, Account_Binded)"
	// 		+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	// 	let profile= [null, profileObject.getFacultyID(), profileObject.getFullName()
	// 	, profileObject.getDob(), profileObject.getGender(), profileObject.getEmail()
	// 	, profileObject.getDescription(), profileObject.getClassName(), insertId];
	// 	db.query(sql, profile, (err, results, fields) =>{
	//     	if(err){
	//     		return console.error(err.message);
	//     		res.redirect('/manager/createNewStudent?status='+err.message);
	//     	}
	//     	else{
	//     		console.log("ID inserted:" + results.insertId);
	//     		res.redirect('/manager/createNewStudent?status=Created%20sucessfully');
	//     	}
	//     })
	// }
})

router.get('/createNewTeacher',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/createNewTeacher', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

router.post('/createNewTeacher', (req, res)=>{
	let accountObject;
	let profileObject;
	let insertId;
	console.log(req.body);

	accountObject= new Account(req.body.username, req.body.password, 'teacher');
	profileObject= new TeacherProfile(req.body.faculty_id, req.body.full_name, reformatDate(req.body.dob)
		, req.body.gender, req.body.email, "No description yet", req.body.specialization);
	console.log(accountObject.toString());
	console.log(profileObject.toString());

	//if(accountObject.getUsername()=== null) res.redirect('/error?status=Account%20validation%20failed');

	if(accountObject.repOK() && profileObject.repOK()){
		let sql= "INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (?, ?, ?, ?)";
		let account= [null, accountObject.getUsername(), accountObject.getPassword(), accountObject.getRole()];
	    db.query(sql, account, (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/manager/createNewTeacher?status='+err.message);
	    	}
	    	else{
	    		console.log("ID inserted:" + results.insertId);
	    		insertId= results.insertId;
	    		let sql_2= "INSERT INTO TeacherProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Specialization, Account_Binded)"
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
				let profile_2= [null, profileObject.getFacultyID(), profileObject.getFullName()
				, profileObject.getDob(), profileObject.getGender(), profileObject.getEmail()
				, profileObject.getDescription(), profileObject.getSpecialization(), results.insertId];
				console.log(profile_2.toString());
				db.query(sql_2, profile_2, (err2, results2, fields2) =>{
			    	if(err2){
			    		return console.error(err2.message);
			    		res.redirect('/manager/createNewTeacher?status='+err2.message);
			    	}
			    	else{
			    		console.log("ID inserted:" + results2.insertId);
			    		res.redirect('/manager/createNewTeacher?status=Created%20sucessfully');
			    	}
	    		})
	    	}
	    })
	}
	else res.redirect('/error?status=Account%20or%20profile%20validation%20failed');
	// console.log("ID inserted again:" + insertId);


	// if(accountObject.repOK() && profileObject.repOK()){
	// 	let sql= "INSERT INTO TeacherProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Specialization, Account_Binded)"
	// 		+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	// 	let profile= [null, profileObject.getFacultyID(), profileObject.getFullName()
	// 	, profileObject.getDob(), profileObject.getGender(), profileObject.getEmail()
	// 	, profileObject.getDescription(), profileObject.getSpecialization(), insertId];
	// 	console.log(profile.toString());
	// 	db.query(sql, profile, (err, results, fields) =>{
	//     	if(err){
	//     		return console.error(err.message);
	//     		res.redirect('/manager/createNewTeacher?status='+err.message);
	//     	}
	//     	else{
	//     		console.log("ID inserted:" + results.insertId);
	//     		res.redirect('/manager/createNewTeacher?status=Created%20sucessfully');
	//     	}
	//     })
	// }
})

router.get('/createNewManager',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/createNewManager', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

router.post('/createNewManager', (req, res)=>{ // AFK
	let accountObject;
	let profileObject;
	let insertId;
	console.log(req.body);

	accountObject= new Account(req.body.username, req.body.password, 'manager');
	profileObject= new ManagerProfile(req.body.faculty_id, req.body.full_name, reformatDate(req.body.dob)
		, req.body.gender, req.body.email, "No description yet", req.body.position);
	console.log(accountObject.toString());
	console.log(profileObject.toString());

	if(accountObject.repOK() && profileObject.repOK()){
		let sql= "INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (?, ?, ?, ?)";
		let account= [null, accountObject.getUsername(), accountObject.getPassword(), accountObject.getRole()];
	    db.query(sql, account, (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/manager/createNewManager?status='+err.message);
	    	}
	    	else{
	    		console.log("ID inserted:" + results.insertId);
	    		insertId= results.insertId;
	    		let sql_2= "INSERT INTO ManagerProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Position, Account_Binded)"
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
				let profile_2= [null, profileObject.getFacultyID(), profileObject.getFullName()
				, profileObject.getDob(), profileObject.getGender(), profileObject.getEmail()
				, profileObject.getDescription(), profileObject.getPosition(), results.insertId];
				console.log(profile_2.toString());
				db.query(sql_2, profile_2, (err2, results2, fields2) =>{
			    	if(err2){
			    		return console.error(err2.message);
			    		res.redirect('/manager/createNewManager?status='+err2.message);
			    	}
			    	else{
			    		console.log("ID inserted:" + results2.insertId);
			    		res.redirect('/manager/createNewManager?status=Created%20sucessfully');
			    	}
	    		})
	    	}
	    })
	}
	else res.redirect('/error?status=Account%20or%20profile%20validation%20failed');
})

// router.post('/createNewAccount',(req,res)=>{

// 	let accountObject;
// 	if(req.body.role==='student') accountObject= new StudentAccount(req.body.username, req.body.username, req.body.role);
// 	else accountObject= new Account(req.body.username, req.body.password, req.body.role);
// 	console.log(accountObject.toString());
// 	console.log("getUsername"+ accountObject.getUsername()+ "getPassword"+ accountObject.getPassword()
// 		+"getRole"+ accountObject.getRole())

// 	if(accountObject.getUsername()=== null) res.redirect('/error?status=Account%20validation%20failed');

// 	if(accountObject.repOK()){
// 		let sql= "INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (?, ?, ?, ?)";
// 		let account= [null, accountObject.getUsername(), accountObject.getPassword(), accountObject.getRole()];
// 	    db.query(sql, account, (err, results, fields) =>{
// 	    	if(err){
// 	    		return console.error(err.message);
// 	    		res.redirect('/manager/createNewAccount?status='+err.message);
// 	    	}
// 	    	else{
// 	    		console.log("ID inserted:" + results.insertId);
// 	    		res.redirect('/manager/createNewAccount?status=Created%20sucessfully');
// 	    	}
// 	    })
// 	}
// 	else res.redirect('/error?status=Account%20validation%20failed')
// })

//MAKE ANNOUNCEMENT
router.get('/makeAnnouncement',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/makeAnnouncement', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

router.post('/makeAnnouncement',(req,res)=>{
	let today = new Date();
	let date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
	let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
	let dateTime = date+' '+time;
	let announcementObject= new Announcement(req.body.title, req.body.content, dateTime);
	console.log(announcementObject.toString());

	if(announcementObject.getTitle()=== null) res.redirect('/error?status=Announcement%20validation%20failed');

	if(announcementObject.repOK()){
		let sql= "INSERT INTO Announcements(Announcement_ID, Title, Content, Date_Created, Display_ID_Responsible) VALUES (?, ?, ?, ?, ?)";
		let account= [null, announcementObject.getTitle(), announcementObject.getContent(), announcementObject.getDate(), req.session.displayID];
	    db.query(sql, account, (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/manager/makeAnnouncement?status='+err.message);
	    	}
	    	else{
	    		console.log("ID inserted:" + results.insertId);
	    		res.redirect('/manager/makeAnnouncement?status=Created%20sucessfully');
	    	}
	    })
	}
	else res.redirect('/error?status=Account%20validation%20failed')
})

//CREATE COURSE

router.get('/createCourse',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    res.render('manager/createCourse', {
	            style: 'common.css',
	            statusMessage: req.query.status
	    });
	}
})

router.post('/createCourse', (req, res)=>{ // AFK
	let courseObject;
	let insertId;
	console.log(req.body);

	courseObject= new Course(req.body.course_code, req.body.course_name, req.body.course_description);
	console.log(courseObject.toString());

	if(courseObject.repOK()){
		let sql= "INSERT INTO Courses(Course_Code, Course_Name, Course_Description, Grades_Count, Grades_Formula) VALUES (?, ?, ?, ?, ?)";
		let information= [courseObject.getCourseCode(), courseObject.getCourseName(), courseObject.getCourseDescription(), 1, "100"];
	    db.query(sql, information, (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/manager/createCourse?status='+err.message);
	    	}
	    	else{
	    		console.log("ID inserted:" + results.insertId);
	    		res.redirect('/manager/createCourse?status=Created%20successfully');
	    	}
	    })
	}
	else res.redirect('/error?status=Account%20or%20profile%20validation%20failed');
})

//ASSIGN TEACHER

router.get('/assignTeacher',(req,res)=>{
	
	if(!req.session.manager){
		res.redirect('/error?status=Unauthorized%20Access');
	}
	else{
	    db.query("SELECT * FROM COURSES", (err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/error?status='+err.message);
	    	}
	    	else{
	    		db.query("SELECT * FROM TEACHERPROFILE", (err2, results2, fields2) =>{
			    	if(err){
			    		return console.error(err2.message);
			    		res.redirect('/error?status='+err2.message);
			    	}
			    	else{
			    		res.render('manager/assignTeacher', {
					            style: 'common.css',
					            statusMessage: req.query.status,
					            course: results,
					            teacher: results2
					    });
			    	}
	    		})
	    	}
	    })
	}
})

router.post('/assignTeacher', (req, res)=>{ // AFK

	console.log(req.body);
	db.query("INSERT INTO TeachingStaff(Staff_ID, For_Course, Teacher_ID) VALUES (?, ?, ?)"
		, [null, req.body.course_code, req.body.profile_id] ,(err, results, fields) =>{
	    	if(err){
	    		return console.error(err.message);
	    		res.redirect('/error?status='+err.message);
	    	}
	    	else{
	    		res.redirect('/manager/assignTeacher?status=Assigned%20successfully');
	    	}
	})
})


module.exports = router;

