const express = require('express')
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const path = require('path');
const session = require('express-session');

let java= require('java');

java.asyncOptions = {
  asyncSuffix: undefined,     // Don't generate node-style methods taking callbacks
  syncSuffix: ""              // Sync methods use the base name(!!)
  
};


const managerController = require('./controllers/managerController');
const studentController = require('./controllers/studentController');
const teacherController = require('./controllers/teacherController');
const errorController = require('./controllers/errorController');
const loginController = require('./controllers/loginController');




let db= require('./sql/db_connection.js');


let app = express();

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))
app.use(bodyParser.json())

app.set('views',path.join(__dirname,'/views/'))
app.engine('handlebars',exphbs({defaultLayout:'mainLayout'}))
app.set('view engine','handlebars')

app.listen(4444,()=>{
    console.log('Express server is started at 4444')
})


app.get('/',(req,res)=>{
    res.redirect('/homepage');
})

app.get('/homepage',(req,res)=>{
	if(req.session.manager){
		res.redirect('/manager');
	}
	else if(req.session.student){
		res.redirect('/student');
	}
	else if(req.session.teacher){
		res.redirect('/teacher');
	}
	else{
	    res.render('homepage',{
	        style:'common.css'
	    })
    }
})

app.use('/manager', managerController);
app.use('/student', studentController);
app.use('/teacher', teacherController);
app.use('/error', errorController);
app.use('/login', loginController);
