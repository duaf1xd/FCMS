CREATE DATABASE IF NOT EXISTS `fcms` DEFAULT CHARACTER SET utf8 COLLATE utf8_vietnamese_ci;
USE `fcms`;

CREATE TABLE Accounts
(
	Numeric_ID int NOT NULL AUTO_INCREMENT,
	Username varchar(36) NOT NULL UNIQUE,
	Password varchar(36) NOT NULL,
	Role varchar(10) NOT NULL,
	PRIMARY KEY (Numeric_ID)
);

INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (NULL,'manager', 'manager', 'manager');
INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (NULL,'teacher', 'teacher', 'teacher');
INSERT INTO Accounts(Numeric_ID, Username, Password, Role) VALUES (NULL,'student', 'student', 'student');

CREATE TABLE StudentProfile
(
	Profile_ID int NOT NULL AUTO_INCREMENT,
	Faculty_ID varchar(20) NOT NULL UNIQUE,
	Full_Name varchar(60) NOT NULL,
	Dob varchar(15) NOT NULL,
	Gender varchar(10) NOT NULL,
	Email varchar(100) NOT NULL,
	Description varchar(300),
	Class_ID varchar(15) NOT NULL,
	Account_Binded int NOT NULL UNIQUE,
	PRIMARY KEY (Profile_ID),
	FOREIGN KEY (Account_Binded) REFERENCES Accounts(Numeric_ID)
);

INSERT INTO StudentProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Class_ID, Account_Binded) 
VALUES (NULL, '1701040191', 'Nguyễn Duy Thái Sơn', '02/12/1999', 'Male', 'duaf1xd@gmail.com', 'Roses are red, violets are blue, my grades are screwed', '3C-17', 3);

CREATE TABLE TeacherProfile
(
	Profile_ID int NOT NULL AUTO_INCREMENT,
	Faculty_ID varchar(20) NOT NULL UNIQUE,
	Full_Name varchar(60) NOT NULL,
	Dob varchar(15) NOT NULL,
	Gender varchar(10) NOT NULL,
	Email varchar(100) NOT NULL,
	Description varchar(300),
	Specialization varchar(50) NOT NULL,
	Account_Binded int NOT NULL UNIQUE,
	PRIMARY KEY (Profile_ID),
	FOREIGN KEY (Account_Binded) REFERENCES Accounts(Numeric_ID)
);

INSERT INTO TeacherProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Specialization, Account_Binded) 
VALUES (NULL, 'GV13000001', 'Giáo Viên A', '01/11/1983', 'Male', 'fcmsteacher@gmail.com', 'Hi, this is description for teacher', 'Big Data Mining', 2);

CREATE TABLE ManagerProfile
(
	Profile_ID int NOT NULL AUTO_INCREMENT,
	Faculty_ID varchar(20) NOT NULL UNIQUE,
	Full_Name varchar(60) NOT NULL,
	Dob varchar(15) NOT NULL,
	Gender varchar(10) NOT NULL,
	Email varchar(100) NOT NULL,
	Description varchar(300),
	Position varchar(50) NOT NULL,
	Account_Binded int NOT NULL UNIQUE,
	PRIMARY KEY (Profile_ID),
	FOREIGN KEY (Account_Binded) REFERENCES Accounts(Numeric_ID)
);

INSERT INTO ManagerProfile(Profile_ID, Faculty_ID, Full_Name, Dob, Gender, Email, Description, Position, Account_Binded) 
VALUES (NULL, 'CVHT130001', 'Cố Vấn A', '13/12/1985', 'Female', 'fcmsmanager@gmail.com', 'Hi, this is description for manager', 'Academic Coordinator', 1);

CREATE TABLE Announcements
(
	Announcement_ID int NOT NULL AUTO_INCREMENT,
	Title varchar(100) NOT NULL UNIQUE,
	Content varchar(1000) NOT NULL,
	Date_Created varchar(30) NOT NULL,
	Display_ID_Responsible int NOT NULL,
	PRIMARY KEY (Announcement_ID),
	FOREIGN KEY (Display_ID_Responsible) REFERENCES Accounts(Numeric_ID)
);

INSERT INTO Announcements(Announcement_ID, Title, Content, Date_Created, Display_ID_Responsible) 
VALUES (NULL,'This is an example announcement title'
	,'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum'
 	, '3-8-2013 11:12:40', 1);


CREATE TABLE Courses
(
	Course_Code varchar(3) NOT NULL UNIQUE,
	Course_Name varchar(60) NOT NULL UNIQUE,
	Course_Description varchar(500) NOT NULL,
	Grades_Count int,
	Grades_Formula varchar(50),
	PRIMARY KEY (Course_Code)
);

INSERT INTO Courses(Course_Code, Course_Name, Course_Description, Grades_Count, Grades_Formula)
VALUES ('DBS', 'Databases', 'Learn how to use Database Management Systems in this course!', 1, "100");

CREATE TABLE TeachingStaff
(
	Staff_ID int NOT NULL AUTO_INCREMENT,
	For_Course varchar(3) NOT NULL,
	Teacher_ID int NOT NULL,
	PRIMARY KEY (Staff_ID),
	FOREIGN KEY (For_Course) REFERENCES Courses(Course_Code),
	FOREIGN KEY (Teacher_ID) REFERENCES TeacherProfile(Profile_ID)
);

INSERT INTO TeachingStaff(Staff_ID, For_Course, Teacher_ID)
VALUES (NULL, 'DBS', 1);

CREATE TABLE CourseMaterial
(
	Material_ID int NOT NULL AUTO_INCREMENT,
	Material_Title varchar(100) NOT NULL,
	Material_Type varchar(30) NOT NULL,
	Material_Content varchar(500) NOT NULL,
	Material_Of varchar(3) NOT NULL,
	PRIMARY KEY (Material_ID),
	FOREIGN KEY (Material_Of) REFERENCES Courses(Course_Code)
);

INSERT INTO CourseMaterial(Material_ID, Material_Title, Material_Type, Material_Content, Material_Of)
VALUES (NULL, 'Lecture1.pptx', "Presentation", "https://drive.google.com/open?id=1DwwLHWTK0CPeVw9mgvmO1cQ-m8f9SQWl", "DBS");

CREATE TABLE Enrolment
(
	Enrolment_ID int NOT NULL AUTO_INCREMENT,
	Student_ID int NOT NULL,
	Course varchar(3) NOT NULL,
	FinalGrade DECIMAL(5,2) NOT NULL,
	PRIMARY KEY (Enrolment_ID),
	FOREIGN KEY (Student_ID) REFERENCES StudentProfile(Profile_ID),
	FOREIGN KEY (Course) REFERENCES Courses(Course_Code)
);

INSERT INTO Enrolment(Enrolment_ID, Student_ID, Course, FinalGrade)
VALUES (NULL, 1, "DBS", 95.92);